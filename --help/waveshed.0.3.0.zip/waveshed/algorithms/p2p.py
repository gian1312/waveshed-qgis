"""QgsProcessingAlgorithm for P2P Link Analysis (P2P / BATCH_P2P).

Supports both single-link (TX/RX coordinate parameters) and batch
(user-provided CSV) modes.  When no batch file is given, a temporary
2-line CSV is generated from the TX/RX parameters.
"""

from __future__ import annotations

import csv
import math
import os
import tempfile

from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from qgis.core import (
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFile,
    QgsProcessingParameterFolderDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterLayer,
    QgsRasterLayer,
)

from ..core.binary_manager import find_binary
from ..core.job_builder import (
    MIN_ANTENNA_AGL_M,
    VALID_RESOLUTIONS,
    P2PParams,
    batch_max_range_km,
    build_p2p_job,
    height_floor_error,
    write_job_file,
)
from ..core import terrain_adapter
from ..core.terrain_adapter import prepare_terrain
from ..core import api_key
from ..core import binary_manager as bm

# Enum value lists (index-based for QgsProcessingParameterEnum).
# SIMPLE_LOSS was removed in 0.2.0; anything that stored an index against the
# old three-entry list points one slot too high and must be re-picked.
_MODELS = ["LOS", "ITM"]
_RESOLUTIONS = [str(r) for r in VALID_RESOLUTIONS]
_BACKENDS = ["AUTO", "GPU", "CPU"]


class P2PAlgorithm(QgsProcessingAlgorithm):
    """Point-to-Point Link Analysis algorithm for the Processing toolbox."""

    # -- Parameter names (constants) ----------------------------------------

    INPUT_DEM = "INPUT_DEM"
    BATCH_FILE = "BATCH_FILE"
    TX_LAT = "TX_LAT"
    TX_LON = "TX_LON"
    TX_HEIGHT = "TX_HEIGHT"
    RX_LAT = "RX_LAT"
    RX_LON = "RX_LON"
    RX_HEIGHT = "RX_HEIGHT"
    MODEL = "MODEL"
    RESOLUTION = "RESOLUTION"
    BACKEND = "BACKEND"
    OUTPUT_DIR = "OUTPUT_DIR"

    # -- Metadata -----------------------------------------------------------

    def name(self) -> str:
        return "p2p"

    def displayName(self) -> str:
        return "Point-to-Point Link Analysis"

    def group(self) -> str:
        return "Analysis"

    def groupId(self) -> str:
        return "analysis"

    def shortHelpString(self) -> str:
        return (
            "Performs point-to-point RF link analysis using the AETHER engine.\n\n"
            "Supports two modes:\n"
            "  - Single link: Provide TX/RX coordinates directly.\n"
            "  - Batch: Provide a CSV file with multiple S/R entries.\n\n"
            "When a batch CSV is provided, the TX/RX coordinate parameters are "
            "ignored and the CSV drives the analysis.\n\n"
            "Batch CSV format:\n"
            "  S,TX1,47.0563,8.4846,40.0,AGL\n"
            "  R,RX1,47.5000,8.9000,10.0,AGL\n\n"
            "Fields: type(S|R), ID, lat, lon, alt_m, mode(AGL|AMSL)"
        )

    def createInstance(self):
        return P2PAlgorithm()

    # -- Parameter definitions -----------------------------------------------

    def initAlgorithm(self, config: Optional[Dict[str, Any]] = None) -> None:
        # DEM layer
        self.addParameter(
            QgsProcessingParameterRasterLayer(
                self.INPUT_DEM,
                "DEM Layer",
            )
        )

        # Batch file (optional)
        self.addParameter(
            QgsProcessingParameterFile(
                self.BATCH_FILE,
                "Batch CSV File",
                behavior=QgsProcessingParameterFile.Behavior.File,
                fileFilter="CSV Files (*.csv)",
                optional=True,
            )
        )

        # TX coordinates
        self.addParameter(
            QgsProcessingParameterNumber(
                self.TX_LAT,
                "TX Latitude",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=0.0,
                minValue=-90.0,
                maxValue=90.0,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.TX_LON,
                "TX Longitude",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=0.0,
                minValue=-180.0,
                maxValue=180.0,
                optional=True,
            )
        )
        # minValue is the AGL floor (job_builder.MIN_ANTENNA_AGL_M). It is safe
        # as a parameter bound only because this algorithm hardcodes AGL mode
        # (see processAlgorithm's P2PParams) and exposes no mode option. If an
        # AMSL mode is ever exposed here, minValue MUST be removed — an AMSL
        # height is an absolute elevation and is legitimately zero or negative —
        # and the floor check moved into processAlgorithm, conditional on the
        # selected mode, the way _parse_csv already does it per CSV row.
        self.addParameter(
            QgsProcessingParameterNumber(
                self.TX_HEIGHT,
                "TX Height (m AGL)",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=30.0,
                minValue=MIN_ANTENNA_AGL_M,
                maxValue=10000.0,
                optional=True,
            )
        )

        # RX coordinates
        self.addParameter(
            QgsProcessingParameterNumber(
                self.RX_LAT,
                "RX Latitude",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=0.0,
                minValue=-90.0,
                maxValue=90.0,
                optional=True,
            )
        )
        self.addParameter(
            QgsProcessingParameterNumber(
                self.RX_LON,
                "RX Longitude",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=0.0,
                minValue=-180.0,
                maxValue=180.0,
                optional=True,
            )
        )
        # See TX_HEIGHT: minValue is only sound while the mode is hardcoded AGL.
        self.addParameter(
            QgsProcessingParameterNumber(
                self.RX_HEIGHT,
                "RX Height (m AGL)",
                type=QgsProcessingParameterNumber.Type.Double,
                defaultValue=1.5,
                minValue=MIN_ANTENNA_AGL_M,
                maxValue=10000.0,
                optional=True,
            )
        )

        # Analysis options
        self.addParameter(
            QgsProcessingParameterEnum(
                self.MODEL,
                "Propagation Model",
                options=_MODELS,
                defaultValue=0,
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.RESOLUTION,
                "Resolution (m)",
                options=_RESOLUTIONS,
                defaultValue=2,  # index 2 -> "10"
            )
        )
        self.addParameter(
            QgsProcessingParameterEnum(
                self.BACKEND,
                "Compute Backend",
                options=_BACKENDS,
                defaultValue=0,
            )
        )

        # Output
        self.addParameter(
            QgsProcessingParameterFolderDestination(
                self.OUTPUT_DIR,
                "Output Directory",
            )
        )

    # -- Processing ----------------------------------------------------------

    def processAlgorithm(
        self,
        parameters: Dict[str, Any],
        context: Any,
        feedback: Any,
    ) -> Dict[str, Any]:
        """Execute the P2P analysis pipeline.

        Steps:
            1. Validate API key
            2. Determine batch file (user-provided or generated from TX/RX)
            3. Compute terrain bounding box from CSV entries
            4. Prepare terrain via terrain_adapter
            5. Build P2P job via job_builder
            6. Run aether_core
            7. Verify aether_core wrote its result CSV
            8. Return output path
        """

        # ---- Resolve parameters ----
        dem_layer: QgsRasterLayer = self.parameterAsRasterLayer(
            parameters, self.INPUT_DEM, context,
        )
        batch_file: Optional[str] = self.parameterAsFile(
            parameters, self.BATCH_FILE, context,
        )
        tx_lat: float = self.parameterAsDouble(parameters, self.TX_LAT, context)
        tx_lon: float = self.parameterAsDouble(parameters, self.TX_LON, context)
        tx_height: float = self.parameterAsDouble(parameters, self.TX_HEIGHT, context)
        rx_lat: float = self.parameterAsDouble(parameters, self.RX_LAT, context)
        rx_lon: float = self.parameterAsDouble(parameters, self.RX_LON, context)
        rx_height: float = self.parameterAsDouble(parameters, self.RX_HEIGHT, context)

        model_idx: int = self.parameterAsEnum(parameters, self.MODEL, context)
        resolution_idx: int = self.parameterAsEnum(parameters, self.RESOLUTION, context)
        backend_idx: int = self.parameterAsEnum(parameters, self.BACKEND, context)

        output_dir: str = self.parameterAsString(parameters, self.OUTPUT_DIR, context)

        model = _MODELS[model_idx]
        resolution_m = int(_RESOLUTIONS[resolution_idx])
        backend = _BACKENDS[backend_idx]

        os.makedirs(output_dir, exist_ok=True)

        # ---- 1. Determine batch file ----
        is_batch = bool(batch_file and batch_file.strip())

        if not is_batch:
            # Generate temp 2-line CSV from TX/RX params.
            feedback.setProgressText("Generating single-link batch CSV...")
            batch_file = self._write_temp_csv(
                tx_lat, tx_lon, tx_height,
                rx_lat, rx_lon, rx_height,
            )

        # ---- 3. Compute terrain bbox from CSV entries ----
        feedback.setProgressText("Computing terrain extents...")
        feedback.setProgress(5)

        entries = self._parse_csv(batch_file)
        (centre_lat, centre_lon,
         terrain_radius_km) = self._compute_terrain_extent(entries)

        if feedback.isCanceled():
            return {}

        # ---- 4. Prepare terrain ----
        feedback.setProgressText("Preparing terrain tiles...")
        feedback.setProgress(10)

        try:
            bm.check_engine_for_job(resolution_m)
        except bm.EngineTooOldError as exc:
            raise QgsProcessingException(str(exc)) from exc

        abt_dir = prepare_terrain(
            dem_layer=dem_layer,
            tx_lat=centre_lat,
            tx_lon=centre_lon,
            max_range_km=terrain_radius_km,
            resolution_m=resolution_m,
            binary_manager=bm,
            feedback=feedback,
            # Terrain occupies the 10-20 % stretch of this algorithm's bar.
            progress_span=(10.0, 20.0),
        )

        if feedback.isCanceled():
            return {}

        # ---- 5. Build job config ----
        feedback.setProgressText("Building job configuration...")
        feedback.setProgress(20)

        output_name = f"p2p_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        # NOTE: in batch mode (is_batch) the CSV drives every link and these
        # tx/rx heights are inert fallbacks that aether_core does not use, so
        # the model-validity pass build_p2p_job runs on them (log_model_warnings)
        # describes a link that is not being computed. The per-row limits that
        # actually matter — the AGL floor and the AGL/AMSL mode — are enforced in
        # _parse_csv above, which is the batch path's real gate. Deliberately not
        # re-running the ITM envelope check per CSV row: it would repeat the
        # frequency/range/refractivity warnings once per site in the log for no
        # extra information. If per-row ITM height warnings are ever wanted, add
        # them in _parse_csv where the row values live, not here.
        params = P2PParams(
            tx_lat=tx_lat,
            tx_lon=tx_lon,
            tx_height=tx_height,
            tx_mode="AGL",
            freq_mhz=433.0,
            erp_watts=10.0,
            rx_height=rx_height,
            rx_mode="AGL",
            model=model,
            resolution_m=resolution_m,
            # NOT the terrain radius: aether_core reads max_range_km as the
            # per-link distance CAP and answers 0/0 for anything longer, so
            # it is sized on the longest link in the batch.
            max_range_km=batch_max_range_km(entries, terrain_radius_km),
            backend=backend,
            output_name=output_name,
        )

        job_config = build_p2p_job(params, abt_dir, output_dir, batch_file=batch_file)
        job_file = write_job_file(job_config, output_dir, output_name)

        if feedback.isCanceled():
            return {}

        # ---- 6. Run aether_core ----
        feedback.setProgressText("Running aether_core...")
        feedback.setProgress(25)

        core_exe = find_binary("aether_core")

        # aether_core is licensed — validate the API key and inject it as
        # AETHER_LICENSE. (aether_converter / aether_export are unlicensed.)
        core_env = os.environ.copy()
        try:
            api_key.apply_license_env(core_env)
        except api_key.ApiKeyError as exc:
            raise QgsProcessingException(str(exc)) from exc

        # aether_core writes all its diagnostics to stdout — surface every
        # line and keep a tail for the error message. Streams through the one
        # shared subprocess runner (terrain_adapter.run_converter_streaming).
        output_lines: list[str] = []

        def on_line(line: str) -> None:
            if feedback.isCanceled():
                raise terrain_adapter.ConverterCancelled()
            output_lines.append(line)
            feedback.pushInfo(line)

        try:
            rc = terrain_adapter.run_converter_streaming(
                core_exe, ["--config", job_file], on_line, env=core_env)
        except terrain_adapter.ConverterCancelled:
            return {}
        if rc != 0:
            tail = "\n".join(output_lines[-20:])
            raise QgsProcessingException(
                f"aether_core exited with code {rc}:\n{tail}"
                + bm.engine_error_hint(tail)
            )

        if feedback.isCanceled():
            return {}

        # ---- 7. Verify output files ----
        # P2P produces output directly -- no aether_export step. aether_core
        # writes <output_name>.csv itself and never writes a .bit/.tiles pair,
        # so running the exporter here only ever failed on a missing input.
        feedback.setProgressText("Verifying output files...")
        feedback.setProgress(80)

        output_path = os.path.join(output_dir, output_name + ".csv")
        if not os.path.isfile(output_path):
            raise QgsProcessingException(
                f"Expected P2P result CSV not found: {output_path}\n"
                "aether_core may have failed to produce output."
            )

        feedback.setProgress(100)
        feedback.setProgressText("Complete.")

        return {self.OUTPUT_DIR: output_path}

    # -- Helpers -------------------------------------------------------------

    @staticmethod
    def _write_temp_csv(
        tx_lat: float,
        tx_lon: float,
        tx_height: float,
        rx_lat: float,
        rx_lon: float,
        rx_height: float,
    ) -> str:
        """Write a temporary 2-line batch CSV for single-link analysis."""
        path = os.path.join(
            tempfile.gettempdir(),
            f"aether_p2p_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        )
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow([
                "S", "TX",
                f"{tx_lat:.6f}", f"{tx_lon:.6f}",
                f"{tx_height:.1f}", "AGL",
            ])
            writer.writerow([
                "R", "RX",
                f"{rx_lat:.6f}", f"{rx_lon:.6f}",
                f"{rx_height:.1f}", "AGL",
            ])
        return path

    @staticmethod
    def _parse_csv(
        path: str,
    ) -> List[Tuple[str, str, float, float, float, str]]:
        """Parse an AETHER batch CSV.

        Returns a list of (type, id, lat, lon, alt_m, mode) tuples.

        This is the *only* validation a batch run gets: when BATCH_FILE is
        supplied the TX/RX parameters are ignored entirely and the CSV drives
        every link, so the parameter bounds in ``initAlgorithm`` never see these
        values. Altitude and mode are therefore checked here, matching
        ``gui.p2p_tab._parse_batch_csv``.

        Raises:
            QgsProcessingException: On a malformed row, an unknown mode, or an
                AGL altitude below ``MIN_ANTENNA_AGL_M``.
        """
        entries: List[Tuple[str, str, float, float, float, str]] = []
        with open(path, "r", newline="", encoding="utf-8-sig") as fh:
            reader = csv.reader(fh)
            for line_no, row in enumerate(reader, start=1):
                if not row or row[0].startswith("#"):
                    continue
                if len(row) < 6:
                    raise QgsProcessingException(
                        f"Batch CSV line {line_no}: expected 6 fields, got {len(row)}"
                    )
                row_type = row[0].strip().upper()
                if row_type not in ("S", "R"):
                    raise QgsProcessingException(
                        f"Batch CSV line {line_no}: type must be 'S' or 'R', "
                        f"got '{row[0].strip()}'"
                    )
                mode = row[5].strip().upper()
                if mode not in ("AGL", "AMSL"):
                    raise QgsProcessingException(
                        f"Batch CSV line {line_no}: mode must be AGL or AMSL, "
                        f"got '{row[5].strip()}'"
                    )
                try:
                    altitude = float(row[4].strip())
                except ValueError as exc:
                    raise QgsProcessingException(
                        f"Batch CSV line {line_no}: altitude is not a number, "
                        f"got '{row[4].strip()}'"
                    ) from exc
                # AGL rows only. An AMSL row is an absolute elevation and is
                # legitimately zero or negative (Dead Sea shore -430 m).
                floor_error = height_floor_error(
                    f"Batch CSV line {line_no}: altitude", altitude, mode,
                )
                if floor_error is not None:
                    raise QgsProcessingException(floor_error)
                entries.append((
                    row_type,
                    row[1].strip(),
                    float(row[2].strip()),
                    float(row[3].strip()),
                    altitude,
                    mode,
                ))
        return entries

    @staticmethod
    def _compute_terrain_extent(
        entries: List[Tuple[str, str, float, float, float, str]],
    ) -> Tuple[float, float, float]:
        """Compute (centre_lat, centre_lon, max_range_km) from CSV entries.

        Returns the centroid of all points and a radius large enough to
        enclose them all (with a 5 km safety margin, minimum 10 km).
        """
        lats = [e[2] for e in entries]
        lons = [e[3] for e in entries]

        min_lat, max_lat = min(lats), max(lats)
        min_lon, max_lon = min(lons), max(lons)

        centre_lat = (min_lat + max_lat) / 2.0
        centre_lon = (min_lon + max_lon) / 2.0

        lat_span_km = (max_lat - min_lat) * 111.0
        cos_lat = math.cos(math.radians(centre_lat))
        if cos_lat < 1e-6:
            cos_lat = 1e-6
        lon_span_km = (max_lon - min_lon) * 111.0 * cos_lat
        half_diag_km = math.sqrt(lat_span_km**2 + lon_span_km**2) / 2.0

        max_range_km = max(half_diag_km + 5.0, 10.0)

        return centre_lat, centre_lon, max_range_km
